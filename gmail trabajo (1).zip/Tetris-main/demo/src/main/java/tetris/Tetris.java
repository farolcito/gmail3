package tetris;

public class Tetris extends Board{
    

}
package tetris;

public interface iRotator {
    
        char[][] rotateLeft(char[][] inputMatrix);
        
        char[][] rotateRight(char[][] inputMatrix);
        
}
